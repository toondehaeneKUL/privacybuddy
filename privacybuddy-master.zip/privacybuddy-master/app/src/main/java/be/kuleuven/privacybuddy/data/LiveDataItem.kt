package be.kuleuven.privacybuddy.data

data class LiveDataItem(
    val packageName: String,
    val permissionGroup: String,
    val accessTime: String
)
