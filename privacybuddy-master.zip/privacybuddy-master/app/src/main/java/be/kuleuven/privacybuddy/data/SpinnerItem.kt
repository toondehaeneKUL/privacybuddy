package be.kuleuven.privacybuddy.data

import android.graphics.drawable.Drawable

data class SpinnerItem(val appIcon: Drawable, val appName: String)
